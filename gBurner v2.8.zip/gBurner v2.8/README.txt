THANK YOU FOR DOWNLOADING MY FILE --> Seven7i 

----------------------------------------------------------------------------------------
 I. DOWNLOAD INFORMATION							
----------------------------------------------------------------------------------------

gBurner v2.8

gBurner is a powerful and easy-to-use CD/DVD burning tool, which allows you to create 
and burn data/audio/video CDs and DVDs, make bootable data CDs and DVDs, create 
multisession discs. gBurner is also a disc image file processing tool, which allows you
to open, create, extract, edit, convert and burn ISO/BIN image files.

----------------------------------------------------------------------------------------
 02. INSTALL INSTRUCTIONS      							
----------------------------------------------------------------------------------------

- Run "gburner28.exe" as administrator to start installation.
- Follow on screen instructions and complete installation.
- Go to FIX folder, use registration details given in KEY.txt file.
- Enter those key details in gBurner to register (gBurner > Help > Register)

Now you copy is registered ! Enjoy !


----------------------------------------------------------------------------------------
 03. UNINSTALL INSTRUCTIONS  							
----------------------------------------------------------------------------------------

- Open Control Panel > Programs > Uninstall a program > Select a program and uninstall.

-----------------------------------------------------------------------------------------
 04. IMPORTANT NOTE								
-----------------------------------------------------------------------------------------

- All my uploads are educational and experimental purpose.Please delete them after 24hrs.
  If you like the program please purchase it and encourage the developers.

- The FIX May be read as Trojan some times, but it is a false alert.so there is nothing 
  to worry about, just disable your Security for some time and apply FIX.

- I'm not responsile for any damage happen to your computer after Installing this program.
  Because I'm not the orginal developer of it. SO, INSTALL THIS ON YOUR OWN RISK. 

-----------------------------------------------------------

� 2010 All rights reserved to "Seven7i"�.Please do not make modifications in this file. 
