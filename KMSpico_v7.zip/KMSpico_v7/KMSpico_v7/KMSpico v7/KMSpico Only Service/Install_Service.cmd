@echo off
pushd "%~dp0"
set directorio=%~dp0
set name="Service KMSELDI"
sc create %name% binPath= "%directorio%Service_KMS.exe" type= own error= normal start= auto DisplayName= %name%
sc start %name%
popd
exit
