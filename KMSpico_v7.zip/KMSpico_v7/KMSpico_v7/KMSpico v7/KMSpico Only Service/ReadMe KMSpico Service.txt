Important: If you like MS Windows and MS Office please buy legal and original
			this program help to test this products, but recommend you buy legal.
			I did this for fun, and now I am done with this. 
			Working in W8 and Office 2013 fresh install and VOLUMEN LICENSE editions.
			Ja mata ne, Farewell, Hejd�, Ciao, Aloha, Zegnaj, Doei

KMSpico v7 Service Edition

- Requirements: .NET 4.0 or Windows 8/2012.
- Activate: Windows Vista/7/8/8.1  
			Office 2010/2013 
			Windows Server 2008/2008R2/2012

0. Disable SmartScreen.
1. Run Install_Service.cmd
2. Done.

Based off of KMSEmulator of CODYQX4,Hotbird64,qad,deagles.

Thanks to Hotbird64, deagles, mikmik38, qad, CODYQX4, xinso. All the credits for they.
Thanks MyDigitalLife.info
Thanks hui.

Recommendations Optional:

- Make exceptions to Directory %ProgramFiles%\KMSpico\*.exe in Antivirus or Defender.

How This Program Works:

1. Check Activation Status
2. Detect VL or Retail (Windows) and depending of the License Status activate or convert to VL.
3. Being a windows service it reactive every windows start.

Change Log:
- Redesigned and Recoded.
- Removed funtions with slmgr.vbs and ospp.vbs.
- Implemented 2 diferent kms emulators. If one fail the other maybe not.
- Fixed bug in W7.
- Add Support for W8.1
- Convertion from Retail to VL changed (faster).
- Now KMSELDI, AutoPico, Service_KMS do the same process for activation.
- Add /silent command line to AutoPico.
- Improved log files.