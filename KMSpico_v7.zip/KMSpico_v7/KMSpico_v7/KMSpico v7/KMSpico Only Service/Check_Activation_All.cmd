@echo off
pushd "%~dp0"
echo Please wait...
TriggerKMS.exe /pause
popd




