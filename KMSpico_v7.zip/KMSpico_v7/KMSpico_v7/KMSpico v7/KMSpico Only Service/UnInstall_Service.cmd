@echo off
pushd "%~dp0"
set name="Service KMSELDI"
sc stop %name% 
sc delete %name% 
popd
exit
