Important: If you like MS Windows and MS Office please buy legal and original
			this program help to test this products, but recommend you buy legal.
			I did this for fun, and now I am done with this. 
			Working in W8 and Office 2013 fresh install and VOLUMEN LICENSE editions.
			Ja mata ne, Farewell, Hejd�, Ciao, Aloha, Zegnaj, Doei

KMSpico v7 Setup Edition.

- Requirements: .NET 4.0 or Windows 8/2012.
- Activate: Windows Vista/7/8/8.1  
			Office 2010/2013 
			Windows Server 2008/2008R2/2012

0. Disable SmartScreen on Windows 8.
1. Run KMSpico_Install_v7.exe
2. Install it.
3. Done.

Based off of KMSEmulator of CODYQX4,Hotbird64,qad,deagles.

Thanks to Hotbird64, deagles, mikmik38, qad, CODYQX4, xinso. All the credits for they.
Thanks MyDigitalLife.info
Thanks hui.

Recommendations Optional:

- Make exceptions to Directory %ProgramFiles%\KMSpico\*.exe in Antivirus or Defender.

How This Program Works:

1. Install KMSPico v7 in Windows.
2. Run automatically KMSELDI and AutoPico.
2.1 Make Tokens Backup.
2.2 Detect VL or Retail and depending of the License Status activate or convert to VL.
2.3 Activate for 180 days all VL products found.
3. Install a windows service that reactive every windows start.
4. Create a task schedule for AutoPico to run every 24 hours.

Change Log:
- Redesigned and Recoded.
- Removed funtions with slmgr.vbs and ospp.vbs.
- Implemented 2 diferent kms emulators. If one fail the other maybe not.
- Fixed bug in W7.
- Add Support for W8.1
- Convertion from Retail to VL changed (faster).
- Now KMSELDI, AutoPico, Service_KMS do the same process for activation.
- Add /silent command line to AutoPico.
- Improved log files.


