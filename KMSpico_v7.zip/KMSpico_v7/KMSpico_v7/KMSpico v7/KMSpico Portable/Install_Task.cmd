@echo off
pushd "%~dp0"
set directorio=%~dp0
set name="AutoPico Daily Restart"
SCHTASKS /Create /TN %name% /TR "%directorio%AutoPico.exe /silent" /SC DAILY /ST 11:59:59 /RU SYSTEM /RL Highest /F
popd
exit
