KMSpico

Use any of the Editions: Install, OEM , Only Service or Portable, dont need to use more than 1 edition,
one edition is enough, I recommend the more complete: Install Edition.